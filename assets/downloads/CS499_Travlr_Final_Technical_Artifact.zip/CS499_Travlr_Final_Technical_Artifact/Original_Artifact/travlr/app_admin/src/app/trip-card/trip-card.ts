import { Component, OnInit, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Trip } from '../models/trip';
import { Authentication } from '../services/authentication';

@Component({
  selector: 'app-trip-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './trip-card.html',
  styleUrl: './trip-card.css'
})
export class TripCardComponent implements OnInit {
  @Input('trip') trip: any;
  public readonly isLoggedIn$;
  private readonly currencyFormatter = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
  });

  constructor(private router: Router, private authenticationService: Authentication) {
    this.isLoggedIn$ = this.authenticationService.isLoggedIn$;
  }
  ngOnInit(): void {
  }

  public formatPrice(value: string | number | null | undefined): string {
    const amount = Number(value);

    if (!Number.isFinite(amount)) {
      return 'Price unavailable';
    }

    return this.currencyFormatter.format(amount);
  }

  public editTrip(trip: Trip) {
    localStorage.removeItem('tripCode');
    localStorage.setItem('tripCode', trip.code);
    this.router.navigate(['edit-trip']);
  }
}
