import { Inject, Injectable } from '@angular/core';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { BROWSER_STORAGE } from '../storage';
import { User } from '../models/user';
import { AuthResponse } from '../models/auth-response';
import { TripDataService } from '../services/trip-data';

@Injectable({
    providedIn: 'root'
})
export class Authentication {
    // Setup our storage and service access
    // Variable to handle Authentication Responses
    authResp: AuthResponse = new AuthResponse();
    private readonly loggedInSubject = new BehaviorSubject<boolean>(false);
    public readonly isLoggedIn$ = this.loggedInSubject.asObservable();

    constructor(
        @Inject(BROWSER_STORAGE) private storage: Storage,
        private tripDataService: TripDataService
    ) {
        this.loggedInSubject.next(this.hasValidToken());
    }

    // Get our token from our Storage provider.
    // NOTE: For this application we have decided that we will name
    // the key for our token 'travlr-token'
    public getToken(): string {
        let out: any;
        out = this.storage.getItem('travlr-token');
        // Make sure we return a string even if we don't have a token
        if (!out) {
            return '';
        }
        return out;
    }
    // Save our token to our Storage provider.
    // NOTE: For this application we have decided that we will name
    // the key for our token 'travlr-token'
    public saveToken(token: string): void {
        this.storage.setItem('travlr-token'
            , token);
        this.loggedInSubject.next(this.hasValidToken());
    }
    // Logout of our application and remove the JWT from Storage
    public logout(): void {
        this.storage.removeItem('travlr-token');
        this.loggedInSubject.next(false);
    }

    // Boolean to determine if we are logged in and the token is
    // still valid. Even if we have a token we will still have to
    // reauthenticate if the token has expired
    public isLoggedIn(): boolean {
        return this.loggedInSubject.value;
    }

    private hasValidToken(): boolean {
        const token: string = this.getToken();
        if (token) {
            try {
                const payload = JSON.parse(atob(token.split('.')[1]));
                return payload.exp > (Date.now() / 1000);
            } catch {
                return false;
            }
        } else {
            return false;
        }
    }
    // Retrieve the current user. This function should only be called
    // after the calling method has checked to make sure that the user
    // isLoggedIn.
    public getCurrentUser(): User {
        const token: string = this.getToken();
        const { email, name } = JSON.parse(atob(token.split('.')[1]));
        return { email, name } as User;
    }

    public login(user: User, passwd: string): Observable<AuthResponse> {
        return this.tripDataService.login(user, passwd)
            .pipe(
                tap((value: AuthResponse) => {
                    this.authResp = value;
                    this.saveToken(this.authResp.token);
                })
            );
    }

    public register(user: User, passwd: string): Observable<AuthResponse> {
        return this.tripDataService.register(user, passwd)
            .pipe(
                tap((value: AuthResponse) => {
                    this.authResp = value;
                    this.saveToken(this.authResp.token);
                })
            );
    }

}
