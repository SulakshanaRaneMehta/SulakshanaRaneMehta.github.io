import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Authentication } from '../services/authentication';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './navbar.html',
  styleUrl: './navbar.css',
})

export class Navbar implements OnInit {
  public readonly isLoggedIn$;

  constructor(
    private authenticationService: Authentication,
    private router: Router
  ) {
    this.isLoggedIn$ = this.authenticationService.isLoggedIn$;
  }
  ngOnInit() { }
  public onLogout(): void {
    this.authenticationService.logout();
    this.router.navigate(['']);
  }
}
