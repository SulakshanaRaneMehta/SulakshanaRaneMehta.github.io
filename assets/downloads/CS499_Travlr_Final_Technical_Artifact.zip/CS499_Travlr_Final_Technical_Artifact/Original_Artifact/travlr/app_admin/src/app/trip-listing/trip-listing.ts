import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Trip } from '../models/trip';
import { TripDataService } from '../services/trip-data';
import { TripCardComponent } from '../trip-card/trip-card';
import { Authentication } from '../services/authentication';
import { Router } from '@angular/router';


@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [CommonModule, TripCardComponent],
  templateUrl: './trip-listing.html',
  styleUrl: './trip-listing.css',
  providers: [TripDataService]
})

export class TripListingComponent implements OnInit {

  trips: Trip[] = [];
  message = '';
  public readonly isLoggedIn$;

  constructor(private tripDataService: TripDataService, 
    private router: Router,
    private cdr: ChangeDetectorRef,
    private authenticationService: Authentication
  ) {
    this.isLoggedIn$ = this.authenticationService.isLoggedIn$;
    console.log('trip-listing constructor');
  }

  public addTrip(): void {
    this.router.navigate(['add-trip']);
  }

  private getStuff(): void {
    this.tripDataService.getTrips()
      .subscribe({
        next: (value: Trip[]) => {
          this.trips = value;
          if (value.length > 0) {
            this.message = 'There are ' + value.length + ' trips available.';
          }
          else {
            this.message = 'There were no trips retireved from the database';
          }
          this.cdr.detectChanges();
          console.log(this.message);
        },
        error: (error: any) => {
          console.log('Error: ' + error);
        }
      })
  }

   ngOnInit(): void {
    console.log('ngOnInit');
    this.getStuff();
  }
}
