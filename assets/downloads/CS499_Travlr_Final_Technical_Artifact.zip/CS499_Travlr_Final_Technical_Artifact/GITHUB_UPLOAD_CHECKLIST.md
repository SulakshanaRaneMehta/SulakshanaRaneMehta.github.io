# GitHub Upload Checklist

This checklist is for Sulakshana to use when updating her own repositories. No GitHub repository is modified by this package.

## Final enhanced repository

Upload the contents of:

```text
Enhanced_Artifact/travlr/
```

Before committing, confirm that the repository does **not** contain:

- `.env`
- real JWT secrets or credentials
- `node_modules/`
- `app_admin/node_modules/`
- `.angular/` or `.angular/cache/`
- `dist/`
- `.DS_Store`
- `__MACOSX/`
- nested `.git/` folders

Keep `.env.example`.

## README check

The repository README should describe the project as the **final CS 499 enhanced artifact**, not as Milestone Three. It should mention all three enhancement categories and the final database verification results.

## Original artifact

For the portfolio's original-artifact link, use the existing CS 465 repository if it accurately represents the original project. If a downloadable original ZIP is provided, use the sanitized `Original_Artifact/travlr/` copy in this package rather than the raw development ZIP containing dependencies or local environment files.

## Verification files to keep

Keep the following final evidence in the enhanced repository:

- `verification/database-verification-report.json`
- `verification/api-smoke-test-report.json`
- `verification/server-test-result.txt`
- `verification/static-javascript-check.txt`
- `PHASE3_VERIFICATION.md`
- `PHASE4_VERIFICATION.md`

## Final safety check before push

Run a repository search for common secret patterns and verify that only placeholders appear in `.env.example`. Then confirm that all links in the README point to files that actually exist in the repository.
